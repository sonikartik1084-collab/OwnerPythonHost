# Owner Python Host — Android project

This is a private local Android app project for importing `.py` files, running them with embedded Python, viewing output, deleting files, and checking storage. It has no INTERNET permission, server, or public-user access. Files are stored in app-private internal storage.

## Build an APK
1. Install Android Studio on a computer.
2. Extract the ZIP and open the `OwnerPythonHost` folder in Android Studio.
3. Allow Gradle sync. Use JDK 17 (Android Studio's bundled JDK is suitable).
4. Install Android SDK Platform 35 and Build Tools when prompted.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When the build completes, click **locate**. The debug APK is usually `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer the APK to your Android phone and install it. Allow installs from that file manager if Android prompts you.

## Use
- Tap Upload Python file and choose a `.py` file.
- Tap Run beside a file.
- View output in Latest Output or tap Show latest logs.
- Tap Stop current script to request a cooperative stop.
- Tap Delete beside a file to remove it.
- Storage usage is shown near the top.

## Limits and safety
- A compiled APK is not included: Android Gradle/SDK build tools are not available in this file-generation environment.
- Chaquopy embeds Python; this is not a Linux server and does not make the phone a public 24/7 host.
- Stop is cooperative. Python cannot safely force-kill an arbitrary thread. A script that loops forever or blocks in native code may not stop until it returns. Scripts can periodically check `from host_runtime import host_should_stop` and break when it returns True.
- Dependencies are not installed dynamically by the UI. Add packages in `app/build.gradle` inside the Chaquopy `pip { install ... }` block, then rebuild.
- Some Telegram/native-extension/Linux-specific scripts may not work on Android.
- Only run code you understand. Scripts run with the Android app's permissions.
