package com.scry.ownerhost;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.View;
import android.widget.*;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private static final int PICK_PY = 101;
    private File rootDir, scriptsDir, logsDir;
    private LinearLayout main, fileList;
    private TextView status, logView, storageView;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile boolean isRunning = false;
    private volatile String activeName = "";
    private final int ink = 0xFF18212F;
    private final int accent = 0xFF3157D5;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        rootDir = new File(getFilesDir(), "owner_host");
        scriptsDir = new File(rootDir, "scripts");
        logsDir = new File(rootDir, "logs");
        scriptsDir.mkdirs(); logsDir.mkdirs();
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        buildUi();
        refreshFiles();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        main = new LinearLayout(this); main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(24, 24, 24, 24); main.setBackgroundColor(0xFFF4F6FB);
        scroll.addView(main);
        TextView title = new TextView(this);
        title.setText("OWNER PYTHON HOST  ❤️‍🔥"); title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setTextColor(ink);
        main.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Private local app • Files stay on this device");
        subtitle.setTextColor(0xFF526071); subtitle.setPadding(0, 8, 0, 18);
        main.addView(subtitle);
        addButton("＋  Upload Python file", v -> openPicker());
        addButton("↻  Refresh files / storage", v -> refreshFiles());
        addButton("■  Stop current script", v -> stopScript());
        addButton("↻  Restart Python runtime", v -> restartRuntime());
        addButton("▤  Show latest logs", v -> showLogs());
        status = new TextView(this); status.setText("Status: idle");
        status.setTextColor(ink); status.setPadding(0, 12, 0, 8); main.addView(status);
        storageView = new TextView(this); storageView.setTextColor(ink);
        storageView.setPadding(0, 4, 0, 12); main.addView(storageView);
        TextView filesTitle = new TextView(this); filesTitle.setText("YOUR PYTHON FILES");
        filesTitle.setTextColor(ink); filesTitle.setTypeface(null, Typeface.BOLD);
        filesTitle.setPadding(0, 10, 0, 8); main.addView(filesTitle);
        fileList = new LinearLayout(this); fileList.setOrientation(LinearLayout.VERTICAL);
        main.addView(fileList);
        TextView logsTitle = new TextView(this); logsTitle.setText("LATEST OUTPUT");
        logsTitle.setTextColor(ink); logsTitle.setTypeface(null, Typeface.BOLD);
        logsTitle.setPadding(0, 18, 0, 8); main.addView(logsTitle);
        logView = new TextView(this); logView.setTextColor(0xFF222222);
        logView.setTextIsSelectable(true); logView.setTextSize(12);
        logView.setPadding(12,12,12,12); logView.setBackgroundColor(0xFFFFFFFF);
        main.addView(logView);
        setContentView(scroll);
    }

    private void addButton(String label, View.OnClickListener click) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 5, 0, 5); main.addView(b, lp); b.setOnClickListener(click);
    }

    private void openPicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_PY);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_PY || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        String name = displayName(uri);
        if (name == null || !name.toLowerCase().endsWith(".py") ||
            !name.matches("[A-Za-z0-9_.-]{1,80}\\.py")) {
            toast("Choose a .py file with a simple filename."); return;
        }
        File dest = new File(scriptsDir, name);
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(dest)) {
            if (in == null) throw new IOException("Could not open file");
            byte[] buf = new byte[8192]; int n; long total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > 1024 * 1024) throw new IOException("File exceeds 1 MB limit");
                out.write(buf, 0, n);
            }
            toast("Uploaded " + name); refreshFiles();
        } catch (Exception e) {
            dest.delete(); toast("Upload failed: " + e.getMessage());
        }
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (ix >= 0) return c.getString(ix);
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void refreshFiles() {
        fileList.removeAllViews();
        File[] fs = scriptsDir.listFiles((d,n) -> n.toLowerCase().endsWith(".py"));
        if (fs == null || fs.length == 0) {
            TextView empty = new TextView(this); empty.setText("No .py files yet. Upload one above.");
            empty.setTextColor(ink); fileList.addView(empty);
        } else {
            for (File f : fs) {
                LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(12,12,12,12); row.setBackgroundColor(0xFFFFFFFF);
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1,-2);
                rp.setMargins(0,4,0,4);
                TextView nm = new TextView(this); nm.setText("🐍 " + f.getName());
                nm.setTextColor(ink); nm.setTypeface(null, Typeface.BOLD); row.addView(nm);
                TextView size = new TextView(this); size.setText(f.length() + " bytes");
                size.setTextColor(0xFF657080); row.addView(size);
                LinearLayout actions = new LinearLayout(this);
                Button run = new Button(this); run.setText("Run"); run.setAllCaps(false);
                Button del = new Button(this); del.setText("Delete"); del.setAllCaps(false);
                actions.addView(run, new LinearLayout.LayoutParams(0,-2,1));
                actions.addView(del, new LinearLayout.LayoutParams(0,-2,1));
                row.addView(actions); fileList.addView(row, rp);
                run.setOnClickListener(v -> runScript(f));
                del.setOnClickListener(v -> confirmDelete(f));
            }
        }
        long used = folderSize(rootDir);
        storageView.setText("Storage used: " + human(used) + " • Files: " + (fs == null ? 0 : fs.length));
    }

    private void runScript(File f) {
        if (isRunning) { toast("A script is already running. Stop it first."); return; }
        isRunning = true; activeName = f.getName();
        status.setText("Status: running " + activeName);
        File log = new File(logsDir, f.getName() + ".log");
        try { new FileOutputStream(log, false).close(); } catch(Exception ignored) {}
        executor.submit(() -> {
            try {
                Python.getInstance().getModule("host_runtime")
                    .callAttr("run_script", f.getAbsolutePath(), log.getAbsolutePath());
            } catch (Throwable e) {
                appendLog(log, "APP ERROR: " + e.toString() + "\n");
            } finally {
                runOnUiThread(() -> {
                    isRunning = false; activeName = "";
                    status.setText("Status: idle"); showLogFile(log); refreshFiles();
                });
            }
        });
    }

    private void stopScript() {
        if (!isRunning) { toast("No script is running."); return; }
        try {
            Python.getInstance().getModule("host_runtime").callAttr("request_stop");
            status.setText("Stop requested for " + activeName + ". Script must cooperate.");
            toast("Stop requested. A script that blocks forever may not stop.");
        } catch (Throwable e) { toast("Stop request failed: " + e.getMessage()); }
    }

    private void restartRuntime() {
        if (isRunning) {
            toast("Stop the script first. Python threads cannot safely be force-killed.");
            return;
        }
        try {
            Python.getInstance().getModule("host_runtime").callAttr("reset_stop");
            status.setText("Status: Python runtime ready");
            toast("Runtime stop flag reset.");
        } catch (Throwable e) { toast("Runtime reset failed: " + e.getMessage()); }
    }

    private void confirmDelete(File f) {
        new android.app.AlertDialog.Builder(this).setTitle("Delete " + f.getName() + "?")
            .setMessage("This cannot be undone.").setNegativeButton("Cancel", null)
            .setPositiveButton("Delete", (d,w) -> {
                if (f.getName().equals(activeName)) { toast("Stop this script first."); return; }
                boolean ok = f.delete(); toast(ok ? "Deleted." : "Delete failed."); refreshFiles();
            }).show();
    }

    private void showLogs() {
        File[] fs = logsDir.listFiles();
        if (fs == null || fs.length == 0) { logView.setText("No logs yet."); return; }
        File latest = fs[0];
        for (File f : fs) if (f.lastModified() > latest.lastModified()) latest = f;
        showLogFile(latest);
    }

    private void showLogFile(File f) {
        try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
            long start = Math.max(0, raf.length() - 12000); raf.seek(start);
            byte[] b = new byte[(int)(raf.length() - start)]; raf.readFully(b);
            logView.setText(new String(b, StandardCharsets.UTF_8));
        } catch (Exception e) { logView.setText("No output yet. " + e.getMessage()); }
    }

    private void appendLog(File f, String s) {
        try (FileOutputStream out = new FileOutputStream(f, true)) {
            out.write(s.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {}
    }
    private long folderSize(File f) {
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        long n = 0; File[] children = f.listFiles();
        if (children != null) for (File c : children) n += folderSize(c);
        return n;
    }
    private String human(long n) {
        if (n < 1024) return n + " B";
        if (n < 1024*1024) return String.format("%.1f KB", n/1024.0);
        return String.format("%.1f MB", n/(1024.0*1024));
    }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    @Override protected void onDestroy() { super.onDestroy(); executor.shutdown(); }
}
